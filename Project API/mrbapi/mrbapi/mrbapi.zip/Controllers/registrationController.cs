﻿using mrbapi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.ModelBinding;

namespace mrbapi.Controllers
{
    public class registrationController : ApiController
    {

        // POST: api/registration
        [HttpPost]
        public IHttpActionResult Postnewuser(string email,string FirstName,string FirstNameAR,  string LastName, string LastNameAR,  string Mobile, string NationalityRef, string Password)

     

        {

          
            if (email == null || FirstName == null || LastName == null || Mobile == null || Password == null)

            {
                Error theError = new Error()
                {
                    Code = "1000",
                    Message = "email,firstname,lastname, and Mobile are mandatory "
                };

                return new ErrorResult(theError, Request);


            }

                registration reg = new registration();
            reg.Email = email;
            reg.FirstName = FirstName;


            reg.FirstNameAR = FirstNameAR == null? "" : FirstNameAR;


            reg.LastName = LastName;
            reg.LastNameAR = LastNameAR == null ? "" : LastNameAR;
            reg.LoginName = email;
               
                reg.Mobile = Mobile;

            if (NationalityRef != null)
            {
                int cntry = Int32.Parse(NationalityRef.ToString());

                reg.NationalityRef = (cntry >= 1) && (cntry <= 210)  ?  cntry : 194;

            }
        else
            {

                reg.NationalityRef = 194;
            }

                reg.Password = Password;
                 
                
            
            registaraction rega = new registaraction();
            try {

                if (email.Trim().Length == 0 || FirstName.Trim().Length == 0 || LastName.Trim().Length == 0 || Mobile.Trim().Length == 0)
                {

                    Error theError = new Error()
                    {
                        Code = "600",
                        Message = "email,firstname,lastname,Mobile, and password are mandatory "
                    };

                    return new ErrorResult(theError, Request);

                }


                if (Password.Trim().Length < 6 )
                {

                    Error theError = new Error()
                    {
                        Code = "900",
                        Message = "password should 6 or more characters"
                    };

                    return new ErrorResult(theError, Request);

                }


                if (!GeneralFunctions.isEmail(email.Trim()))
                    
                    {

                    Error theError = new Error()
                    {
                        Code = "800",
                        Message = "Wrong Email Format"
                    };

                    return new ErrorResult(theError, Request);


                }

                if (rega.IsValidEmail(email))
                {
                    GeneralFunctions GF = new GeneralFunctions();

                    int id = rega.UserRegistration_Aqdar(reg);
                    GF.SendUserActivationEmail(reg.Email, id.ToString(), reg.FirstName + " " + reg.LastName);
                    return Ok(id);
                }

                else
                {

                    Error theError = new Error()
                    {
                        Code = "700",
                        Message = "Email exist"
                    };

                    return new ErrorResult(theError, Request);

                    //var message = new HttpResponseMessage(HttpStatusCode.BadRequest)
                    //{
                    //    Content = new StringContent("Email exist")
                    //};
                    //throw new HttpResponseException(message);

                    // NotFound("Email exist");
                }
            }
            catch  
            {
                
                    return NotFound();
               
               
 
            }



        }
 
    }
}
