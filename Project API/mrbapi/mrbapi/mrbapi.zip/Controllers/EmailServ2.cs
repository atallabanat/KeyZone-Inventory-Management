﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Web;

namespace mrbapi.Controllers
{
    
    public class EmailServ2
    {
        public void SendEmail(EmailMessage message)
        {


            // string _theme = UIHelper.GetSiteDefaultTheme();




            var smtp = new SmtpClient(ConfigurationManager.AppSettings["xo"].ToString(), int.Parse(ConfigurationManager.AppSettings["xoport"].ToString()))
            {
                EnableSsl = true,
                UseDefaultCredentials = true,
                Credentials = new NetworkCredential(ConfigurationManager.AppSettings["xoEmail"].ToString(), ConfigurationManager.AppSettings["xopassword"].ToString())
                //DeliveryMethod = smtpSettings.DeliveryMethod,
            };












            // Set the intended Message Information
            string fromemail = ConfigurationManager.AppSettings["FromEmail"].ToString();

            var mailMessage = new MailMessage
            {
                From = new MailAddress(fromemail),
                Subject = message.Subject,
                IsBodyHtml = message.IsHtml,
                Body = message.Body
            };

            // Recipients in To field
            foreach (var recipientTo in message.To)
            {
                mailMessage.To.Add(recipientTo);
            }

            // Recipients in CC field
            foreach (var recipientCc in message.CC)
            {
                mailMessage.CC.Add(recipientCc);
            }


            foreach (var recipientBcc in message.BCC)
            {
                mailMessage.CC.Add(recipientBcc);
            }

            foreach (var attachment in message.Attachments)
            {
                mailMessage.Attachments.Add(attachment);
            }

            using (smtp)
            {
                ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                try
                {
                    smtp.Send(mailMessage);
                }
                catch (SmtpException ex)
                {

                    throw ex;
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
        }

        public void SendEmail(string subject, string body, string from, string to, string cc, string bcc, string FromDisplayName, bool IsHtml)
        {
            IList<MailAddress> mailTo = new List<MailAddress>();
            IList<MailAddress> mailBCC = new List<MailAddress>();
            IList<MailAddress> mailCC = new List<MailAddress>();


            mailTo.Add(new MailAddress(to));

            if (cc.Trim().Length > 0)
            {
                mailCC.Add(new MailAddress(cc));
            }

            if (bcc.Trim().Length > 0)
            {
                mailBCC.Add(new MailAddress(bcc));
            }

            EmailMessage emailObj = new EmailMessage();

            emailObj.Subject = subject;
            emailObj.Body = body;
            emailObj.To = mailTo;
            emailObj.From = from;
            emailObj.BCC = mailBCC;
            emailObj.CC = mailCC;
            emailObj.FromDisplayName = FromDisplayName;
            emailObj.IsHtml = IsHtml;

            SendEmail(emailObj);
        }




        public void SendEmailForDGEP(string subject, string body, string from, string to, string cc, string bcc, string FromDisplayName, bool IsHtml)
        {
            IList<MailAddress> mailTo = new List<MailAddress>();
            IList<MailAddress> mailBCC = new List<MailAddress>();
            IList<MailAddress> mailCC = new List<MailAddress>();


            mailTo.Add(new MailAddress(to));

            if (cc.Trim().Length > 0)
            {
                mailCC.Add(new MailAddress(cc));
            }

            if (bcc.Trim().Length > 0)
            {
                mailBCC.Add(new MailAddress(bcc));
            }

            EmailMessage emailObj = new EmailMessage();

            emailObj.Subject = subject;
            emailObj.Body = body;
            emailObj.To = mailTo;
            emailObj.From = from;
            emailObj.BCC = mailBCC;
            emailObj.CC = mailCC;
            emailObj.FromDisplayName = FromDisplayName;
            emailObj.IsHtml = IsHtml;

            SendEmail(emailObj);
        }




    }

    public class EmailMessage
    {
        #region Constructors

        public EmailMessage()
        {
            Attachments = new List<Attachment>();
            BCC = new List<MailAddress>();
            CC = new List<MailAddress>();
            To = new List<MailAddress>();
        }

        public EmailMessage(IList<Attachment> attachments, IList<MailAddress> bcc, string body, IList<MailAddress> cc,
            string from, string fromDisplayName, bool isHtml, string subject, IList<MailAddress> to)
        {
            Attachments = attachments;
            BCC = bcc;
            Body = body;
            CC = cc;
            From = from;
            FromDisplayName = fromDisplayName;
            IsHtml = isHtml;
            Subject = subject;
            To = to;
        }

        #endregion Constructors

        #region Properties

        public IList<Attachment> Attachments
        {
            get;
            set;
        }

        public IList<MailAddress> BCC
        {
            get;
            set;
        }

        public string Body
        {
            get;
            set;
        }

        public IList<MailAddress> CC
        {
            get;
            set;
        }

        public string From
        {
            get;
            set;
        }

        public string FromDisplayName
        {
            get;
            set;
        }

        public bool IsHtml
        {
            get;
            set;
        }

        public string Subject
        {
            get;
            set;
        }

        public IList<MailAddress> To
        {
            get;
            set;
        }

        #endregion Properties

    }

    public class EmailTemplate
    {
        #region ContactUS
        public static string ContactAr(string sName, string email, string msg)
        {

            string result = "<div dir='rtl'>" +
                            " <p style='color: #039; font: bold 13px 'Segeo UI', arial, sans-serif'>" +
                            "هذا البريد الالكتروني أرسل من خلال صفحة \"اتصل بنا\" من موقع آفاق المعرفة بالتفاصيل التالية:</p>" +
                            "  <span style='color: #000; font: 12px 'Tahoma', arial, sans-serif'><b>اسم المرسل:</b>" +
                            sName +
                            "</span><br /><span style='color: #000; font: 12px 'Tahoma', arial, sans-serif'><b>عنوان بريد المرسل:</b>" +
                            email +
                            "</span><br /><span style='color: #000; font: 12px 'Tahoma', arial, sans-serif'><b>الرسالة:</b><br />" +
                            msg +
                            "</div>";
            return result;
        }
        public static string ContactEn(string sName, string email, string msg)
        {

            string result = "<div dir='ltr'>" +
                            "<p dir='ltr' lang='en' style='color: #039; font: bold 12px 'Tahoma', arial, sans-serif'>" +
                            "This mail was submitted through \"Contact us\" page from Knowledge Horizon website with the following details: </p>" +
                            "   <span style='color: #000; font:13px 'Segeo UI', arial, sans-serif'><b>Submitter Name:</b> " +
                            sName +
                            "</span> <br /><span style='color: #000; font:13px 'Segeo UI', arial, sans-serif'><b>Submitter Email:</b> " +
                            email +
                            "</span> <br /><span style='color: #000; font:13px 'Segeo UI', arial, sans-serif'><b>Submitted Message:</b><br /> " +
                            msg +
                            "</span></div>";
            return result;
        }


        #endregion

        #region Support
        public static string SupportAr(string sName, string email, string type, string msg)
        {

            string result = "<div dir='rtl'>" +
                            " <p style='color: #039; font: bold 13px 'Segeo UI', arial, sans-serif'>" +
                            "هذا البريد الالكتروني أرسل من خلال صفحة \"الدعم والمساعدة\" من موقع آفاق المعرفة بالتفاصيل التالية:</p>" +
                            "  <span style='color: #000; font: 12px 'Tahoma', arial, sans-serif'><b>اسم المرسل:</b>" +
                            sName +
                          "</span><br /><span style='color: #000; font: 12px 'Tahoma', arial, sans-serif'><b>عنوان بريد المرسل:</b>" +
                            email +
                              "  <span style='color: #000; font: 12px 'Tahoma', arial, sans-serif'><b>الإستعلام عن:</b>" +
                           type +
                            "</span><br /><span style='color: #000; font: 12px 'Tahoma', arial, sans-serif'><b>الرسالة:</b><br />" +
                            msg +
                            "</div>";
            return result;
        }
        public static string SupportEn(string sName, string email, string type, string msg)
        {

            string result = "<div dir='ltr'>" +
                            "<p dir='ltr' lang='en' style='color: #039; font: bold 12px 'Tahoma', arial, sans-serif'>" +
                            "This mail was submitted through \"Help and Support\" page from Knowledge Horizon website with the following details: </p>" +
                            "   <span style='color: #000; font:13px 'Segeo UI', arial, sans-serif'><b>Submitter Name:</b> " +
                            sName +
                            "</span> <br /><span style='color: #000; font:13px 'Segeo UI', arial, sans-serif'><b>Submitter Email :</b> " +
                            email +
                             "</span> <br /><span style='color: #000; font:13px 'Segeo UI', arial, sans-serif'><b>Inquiry About :</b> " +
                            type +
                            "</span> <br /><span style='color: #000; font:13px 'Segeo UI', arial, sans-serif'><b>Submitted Message :</b><br /> " +
                            msg +
                            "</span></div>";
            return result;
        }


        #endregion

        #region Trainee
        public static string CreateTraineeEn(string Title, string FirstName, string LastName, string LoginName, string Password, string ClientManagerName, string ClientManagerEmail, string ClientManagerPhone)
        {

            //Read the file as one string.
            System.IO.StreamReader myFile =
               new System.IO.StreamReader(HttpContext.Current.Server.MapPath("~") + "/Data/EmailTemplates/en/NewUser.htm");
            string myString = myFile.ReadToEnd();
            myFile.Close();

            string SiteLink = ConfigurationManager.AppSettings["SiteLink"].ToString();
            string SiteLinkName = ConfigurationManager.AppSettings["SiteLinkName"].ToString();


            string result = String.Format(myString, Title, FirstName + " " + LastName, LoginName, Password, ClientManagerName, ClientManagerEmail, ClientManagerPhone, SiteLink, SiteLinkName);
            return result;
        }
        public static string CreateTraineeAr(string Title, string FirstName, string LastName, string LoginName, string Password, string ClientManagerName, string ClientManagerEmail, string ClientManagerPhone)
        {

            //Read the file as one string.
            System.IO.StreamReader myFile =
               new System.IO.StreamReader(HttpContext.Current.Server.MapPath("~") + "/Data/EmailTemplates/ar/NewUser.htm");
            string myString = myFile.ReadToEnd();
            myFile.Close();

            string SiteLink = ConfigurationManager.AppSettings["SiteLink"].ToString();
            string SiteLinkName = ConfigurationManager.AppSettings["SiteLinkName"].ToString();

            string result = String.Format(myString, Title, FirstName + " " + LastName, LoginName, Password, ClientManagerName, ClientManagerEmail, ClientManagerPhone, SiteLink, SiteLinkName);
            return result;
        }

        public static string ChangingPasswordTraineeEn(string Title, string FirstName, string LastName, string LoginName, string Password)
        {
            //Read the file as one string.
            System.IO.StreamReader myFile =
               new System.IO.StreamReader(HttpContext.Current.Server.MapPath("~") + "/Data/EmailTemplates/en/ChangePassword.htm");
            string myString = myFile.ReadToEnd();
            myFile.Close();

            string SiteLink = ConfigurationManager.AppSettings["SiteLink"].ToString();
            string SiteLinkName = ConfigurationManager.AppSettings["SiteLinkName"].ToString();

            string result = String.Format(myString, Title, FirstName + " " + LastName, LoginName, Password, SiteLink, SiteLinkName);
            return result;
        }
        public static string ChangingPasswordTraineeAr(string Title, string FirstName, string LastName, string LoginName, string Password)
        {

            //Read the file as one string.
            System.IO.StreamReader myFile =
               new System.IO.StreamReader(HttpContext.Current.Server.MapPath("~") + "/Data/EmailTemplates/ar/ChangePassword.htm");
            string myString = myFile.ReadToEnd();
            myFile.Close();


            string SiteLink = ConfigurationManager.AppSettings["SiteLink"].ToString();
            string SiteLinkName = ConfigurationManager.AppSettings["SiteLinkName"].ToString();

            string result = String.Format(myString, Title, FirstName + " " + LastName, LoginName, Password, SiteLink, SiteLinkName);
            return result;
        }


        #endregion

        #region Trainer

        public static string CreateTrainerEn(string Title, string FirstName, string LastName, string LoginName, string Password)
        {

            //Read the file as one string.
            System.IO.StreamReader myFile =
               new System.IO.StreamReader(HttpContext.Current.Server.MapPath("~") + "/Data/EmailTemplates/en/NewUser.htm");
            string myString = myFile.ReadToEnd();
            myFile.Close();

            string SiteLink = ConfigurationManager.AppSettings["SiteLink"].ToString();
            string SiteLinkName = ConfigurationManager.AppSettings["SiteLinkName"].ToString();

            string result = String.Format(myString, Title, FirstName + " " + LastName, LoginName, Password);
            return result;
        }
        public static string CreateTrainerAr(string Title, string FirstName, string LastName, string LoginName, string Password)
        {

            //Read the file as one string.
            System.IO.StreamReader myFile =
               new System.IO.StreamReader(HttpContext.Current.Server.MapPath("~") + "/EmailTemplates/NewUser.htm");
            string myString = myFile.ReadToEnd();
            myFile.Close();

            string SiteLink = ConfigurationManager.AppSettings["SiteLink"].ToString();
            string SiteLinkName = ConfigurationManager.AppSettings["SiteLinkName"].ToString();

            string result = String.Format(myString, Title, FirstName + " " + LastName, LoginName, Password, FirstName + " " + LastName, LoginName, SiteLink, SiteLinkName, "");
            return result;
        }

        public static string ChangingPasswordTrainerEn(string Title, string FirstName, string LastName, string LoginName, string Password)
        {

            //Read the file as one string.
            System.IO.StreamReader myFile =
               new System.IO.StreamReader(HttpContext.Current.Server.MapPath("~") + "/Data/EmailTemplates/en/ChangePassword.htm");
            string myString = myFile.ReadToEnd();
            myFile.Close();

            string SiteLink = ConfigurationManager.AppSettings["SiteLink"].ToString();
            string SiteLinkName = ConfigurationManager.AppSettings["SiteLinkName"].ToString();

            string result = String.Format(myString, Title, FirstName + " " + LastName, LoginName, Password, SiteLink, SiteLinkName);
            return result;
        }
        public static string ChangingPasswordTrainerAr(string Title, string FirstName, string LastName, string LoginName, string Password)
        {

            //Read the file as one string.
            System.IO.StreamReader myFile =
               new System.IO.StreamReader(HttpContext.Current.Server.MapPath("~") + "/Data/EmailTemplates/ar/ChangePassword.htm");
            string myString = myFile.ReadToEnd();
            myFile.Close();

            string SiteLink = ConfigurationManager.AppSettings["SiteLink"].ToString();
            string SiteLinkName = ConfigurationManager.AppSettings["SiteLinkName"].ToString();

            string result = String.Format(myString, Title, FirstName + " " + LastName, LoginName, Password, SiteLink, SiteLinkName);
            return result;
        }


        #endregion

        #region Training Plan
        public static string CreateTrainingPlanEn(string Title, string Name, string LoginName, string Password)
        {

            string result = "<div style='direction:ltr;'>" +
                    "Dear " + Title + " " + Name + "," +
                    "<br/><br/>" +
                    "We would like to take this opportunity to welcome you to our Training Time System which will give you an access to just-in-time learning opportunities with a unique learning experience." +
                    "<br/><br/>For more details about your training plan, please find attached file." +
                    "<br/><br/>You can login to your account using the details below:" +
                    "<br/><table><tr><td><strong>Login Name</strong>:&nbsp;</td><td>" + LoginName + "</td></tr>" +
                    "<tr><td><strong>Password</strong>:&nbsp;</td><td>" + Password + "</td></tr></table>" +
                    "<br/>We wish you a joyful learning experience!" +
                    "<br/><br/>For more information about your account details and other Training Time™ inquiries, please don't hesitate to contact us using the contact information below:" +
                    "<br/><a href='mailto:support@knowledgehorizon.com' >support@knowledgehorizon.com</a>" +
                    "<br/><br/>Best Regards," +
                    "<br/>Knowledge Horizon Support Desk" +
                    "<br/><a href='http://www.knowledgehorizon.com' >www.knowledgehorizon.com</a>" +
                    "</div>";
            return result;
        }
        public static string CreateTrainingPlanAr(string Title, string Name, string LoginName, string Password)
        {

            string result = "<div style='direction:rtl;'>" +
                    "" + Title + " " + Name + "," +
                    "<br/><br/>" +
                    "نودُّ أن ننتهزَ هذه الفرصة لنُرحِّبَ بدخولكَم إلى نظامنا التدريبي الخاص ™Training Time والذي سيُتيحُ لَكم فرصاً تعلُّميَّةً هي الأحدثُ من نوعها عالميّاً ستزوِّدكم بخبراتٍ ومعارف فريدةٍ من نوعها." +
                    "<br/><br/>للمزيد من التفاصيل الخاصة بخطتك التدريبية، الرجاء النظر إلى الملف المرفق." +
                    "<br/><br/>يمنكم الدخول إلى النظام باستخدام تفاصيل الحساب المُبيَّنة أدناه:" +
                    "<br/><table><tr><td><strong>اسم المستخدم</strong>:&nbsp;</td><td>" + LoginName + "</td></tr>" +
                    "<tr><td><strong>كلمة المرور</strong>:&nbsp;</td><td>" + Password + "</td></tr></table>" +
                    "<br/>ونحنُ نتمنّى لكَ بدورنا تجربة تعلُّميَّةً مُتميِّزة!" +
                    "<br/><br/>للمزيد من المعلومات عن تفاصيل حسابكم وأي طلبات أخرى خاصة بالنظام، الرجاء عدم التردد في الاتصال بنا باستخدام معلومات الاتصال الموجودو فيما يلي:" +
                    "<br/><a href='mailto:support@knowledgehorizon.com' >support@knowledgehorizon.com</a>" +
                    "<br/><br/>مع أطيب التحيات،" +
                    "<br/>فريق دعم آفاق المعرفة" +
                    "<br/><a href='http://www.knowledgehorizon.com' >www.knowledgehorizon.com</a>" +
                    "</div>";
            return result;
        }

        public static string UpdateTrainingPlanEn(string Title, string Name, string LoginName, string Password)
        {
            string result = "<div style='direction:ltr;'>" +
                    "Dear " + Title + " " + Name + "," +
                    "<br/><br/>" +
                    "We would like to take this opportunity to welcome you to our Training Time System which will give you an access to just-in-time learning opportunities with a unique learning experience." +
                    "<br/><br/>For more details about your training plan, please find attached file." +
                    "<br/><br/>You can login to your account using the details below:" +
                    "<br/><table><tr><td><strong>Login Name</strong>:&nbsp;</td><td>" + LoginName + "</td></tr>" +
                    "<tr><td><strong>Password</strong>:&nbsp;</td><td>" + Password + "</td></tr></table>" +
                    "<br/>We wish you a joyful learning experience!" +
                    "<br/><br/>For more information about your account details and other Training Time™ inquiries, please don't hesitate to contact us using the contact information below:" +
                    "<br/><a href='mailto:support@knowledgehorizon.com' >support@knowledgehorizon.com</a>" +
                    "<br/><br/>Best Regards," +
                    "<br/>Knowledge Horizon Support Desk" +
                    "<br/><a href='http://www.knowledgehorizon.com' >www.knowledgehorizon.com</a>" +
                    "</div>";
            return result;
        }
        public static string UpdateTrainingPlanAr(string Title, string Name, string LoginName, string Password)
        {
            string result = "<div style='direction:rtl;'>" +
                    "" + Title + " " + Name + "," +
                    "<br/><br/>" +
                    "نودُّ أن ننتهزَ هذه الفرصة لنُرحِّبَ بدخولكَم إلى نظامنا التدريبي الخاص ™Training Time والذي سيُتيحُ لَكم فرصاً تعلُّميَّةً هي الأحدثُ من نوعها عالميّاً ستزوِّدكم بخبراتٍ ومعارف فريدةٍ من نوعها." +
                    "<br/><br/>للمزيد من التفاصيل الخاصة بخطتك التدريبية، الرجاء النظر إلى الملف المرفق." +
                    "<br/><br/>يمنكم الدخول إلى النظام باستخدام تفاصيل الحساب المُبيَّنة أدناه:" +
                    "<br/><table><tr><td><strong>اسم المستخدم</strong>:&nbsp;</td><td>" + LoginName + "</td></tr>" +
                    "<tr><td><strong>كلمة المرور</strong>:&nbsp;</td><td>" + Password + "</td></tr></table>" +
                    "<br/>ونحنُ نتمنّى لكَ بدورنا تجربة تعلُّميَّةً مُتميِّزة!" +
                    "<br/><br/>للمزيد من المعلومات عن تفاصيل حسابكم وأي طلبات أخرى خاصة بالنظام، الرجاء عدم التردد في الاتصال بنا باستخدام معلومات الاتصال الموجودو فيما يلي:" +
                    "<br/><a href='mailto:support@knowledgehorizon.com' >support@knowledgehorizon.com</a>" +
                    "<br/><br/>مع أطيب التحيات،" +
                    "<br/>فريق دعم آفاق المعرفة" +
                    "<br/><a href='http://www.knowledgehorizon.com' >www.knowledgehorizon.com</a>" +
                    "</div>";
            return result;
        }

        public static string ChangingPasswordTrainingPlanEn(string Title, string Name, string LoginName, string Password)
        {
            string result = "<div style='direction:ltr;'>" +
                    "Dear " + Title + " " + Name + "," +
                    "<br/><br/>" +
                    "We would like to inform you that your account details have been changed as below:" +
                    "<br/><table><tr><td><strong>Login Name</strong>:&nbsp;</td><td>" + LoginName + "</td></tr>" +
                    "<tr><td><strong>Password</strong>:&nbsp;</td><td>" + Password + "</td></tr></table>" +
                    "<br/>For more information about your account details and other Training Time™ inquiries, please don't hesitate to contact us using the contact information below:!" +
                     "<br/><a href='mailto:support@knowledgehorizon.com' >support@knowledgehorizon.com</a>" +
                    "<br/><br/>Best Regards," +
                    "<br/>Knowledge Horizon Support Desk" +
                    "<br/><a href='http://www.knowledgehorizon.com' >www.knowledgehorizon.com</a>" +
                    "</div>";
            return result;
        }
        public static string ChangingPasswordTrainingPlanAr(string Title, string Name, string LoginName, string Password)
        {
            string result = "<div style='direction:rtl;'>" +
                    "" + Title + " " + Name + "," +
                    "<br/><br/>" +
                    "نودُّ إحاطتكم عِلماً بأن تفاصيل الحساب الخاصَّة بكم قد تمَّ تغييرها كما هو مُبيَّنٌ أدناه:" +
                    "<br/><table><tr><td><strong>اسم المستخدم</strong>:&nbsp;</td><td>" + LoginName + "</td></tr>" +
                    "<tr><td><strong>كلمة المرور</strong>:&nbsp;</td><td>" + Password + "</td></tr></table>" +
                    "<br/>للمزيد من المعلومات عن تفاصيل حسابكم وأي طلبات أخرى خاصة بالنظام، الرجاء عدم التردد في الاتصال بنا باستخدام معلومات الاتصال الموجودو فيما يلي:" +
                    "<br/><a href='mailto:support@knowledgehorizon.com' >support@knowledgehorizon.com</a>" +
                    "<br/><br/>مع أطيب التحيات،" +
                    "<br/>فريق دعم آفاق المعرفة" +
                    "<br/><a href='http://www.knowledgehorizon.com' >www.knowledgehorizon.com</a>" +
                    "</div>";
            return result;
        }
        #endregion

        #region Code Login
        public static string CreateCodeLoginTraineeEn(string Title, string FirstName, string LastName, string LoginCode, string LoginName, string Password)
        {

            //Read the file as one string.
            System.IO.StreamReader myFile =
               new System.IO.StreamReader(HttpContext.Current.Server.MapPath("~") + "/Data/EmailTemplates/en/CodeLoginUser.htm");
            string myString = myFile.ReadToEnd();
            myFile.Close();

            string SiteLink = ConfigurationManager.AppSettings["SiteLink"].ToString();
            string SiteLinkName = ConfigurationManager.AppSettings["SiteLinkName"].ToString();


            string result = String.Format(myString, Title, FirstName + " " + LastName, LoginCode, SiteLink, SiteLinkName, LoginName, Password);
            return result;
        }
        public static string CreateCodeLoginTraineeAr(string Title, string FirstName, string LastName, string LoginCode, string LoginName, string Password)
        {

            //Read the file as one string.
            System.IO.StreamReader myFile =
               new System.IO.StreamReader(HttpContext.Current.Server.MapPath("~") + "/Data/EmailTemplates/ar/CodeLoginUser.htm");
            string myString = myFile.ReadToEnd();
            myFile.Close();

            string SiteLink = ConfigurationManager.AppSettings["SiteLink"].ToString();
            string SiteLinkName = ConfigurationManager.AppSettings["SiteLinkName"].ToString();

            string result = String.Format(myString, Title, FirstName + " " + LastName, LoginCode, SiteLink, SiteLinkName, LoginName, Password);
            return result;
        }




        #endregion



    }

}