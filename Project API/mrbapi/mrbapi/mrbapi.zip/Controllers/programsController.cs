﻿using mrbapi.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace mrbapi.Controllers
{
    public class programsController : ApiController
    {
        // GET: api/programs
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        // GET: api/programs/5
        public DataTable Get()
        {
            Porgrams p = new Porgrams();
            DataTable dt = new DataTable();

           dt =  p.GetPrograms_ByTP_ID_ForDDl();

            return dt;
        }

        //// POST: api/programs
        //public void Post([FromBody]string value)
        //{
        //}

        //// PUT: api/programs/5
        //public void Put(int id, [FromBody]string value)
        //{
        //}

        //// DELETE: api/programs/5
        //public void Delete(int id)
        //{
        //}
    }
}
