﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Web;

namespace mrbapi.Controllers
{
    public class GeneralFunctions
    {
        public static bool isArabicString(string inputString)
        {
            try
            {
                bool result = true;
                foreach (char chr in inputString)
                {
                    if (!"0123456789 اآأإئءؤىبتةثجحخدذرزسشصضطظعغفقكلمنهوي".Contains(chr))
                    {
                        result = false;
                    }
                }
                return result;
            }
            catch
            {
                return false;
            }
        }
        public static bool isValidCharacters(string inputString)
        {
            try
            {
                bool result = true;
                foreach (char chr in inputString)
                {
                    if (!"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 اآأإئءؤىبتةثجحخدذرزسشصضطظعغفقكلمنهويًٌٍَُِ_-'\".&,،()~’".Contains(chr))
                    {
                        result = false;
                        break;
                    }
                }
                return result;
            }
            catch
            {
                return false;
            }
        }

        public static bool isEmail(string inputEmail)
        {
            try
            {

                return new RegexUtilities().IsValidEmail(inputEmail);
                //MailAddress ma = new MailAddress(inputEmail);
                //return true;
            }
            catch
            {
                return false;
            }
        }

        public static Boolean IsNumeric(string string_)
        {
            int result;
            if (int.TryParse(string_, out result))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static Boolean IsNumericLong(string string_)
        {
            long result;
            if (long.TryParse(string_, out result))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static Boolean IsFloat(string string_)
        {
            float result;
            if (float.TryParse(string_, out result))
            {
                if (string_.Contains(","))
                { return false; }
                else
                    return true;
            }
            else
            {
                return false;
            }
        }

        public static bool isDate(string date)
        {
            try
            {

                string[] dateParts = date.Split('-');

                DateTime testDate = new
              DateTime(Convert.ToInt32(dateParts[0]),
              Convert.ToInt32(dateParts[1]),
              Convert.ToInt32(dateParts[2]));
                return true;
            }
            catch
            {
                // if a test date cannot be created, the
                // method will return false
                return false;
            }
        }

        public static DateTime GetDateTime(string date)
        {
            try
            {
                //string[] dateParts = date.Split('/');

                //DateTime testDate = new
                //    DateTime(Convert.ToInt32(dateParts[2]),
                //    Convert.ToInt32(dateParts[1]),
                //    Convert.ToInt32(dateParts[0]));
                //return testDate;

                string[] dateParts = date.Split('-');

                DateTime testDate = new
                    DateTime(Convert.ToInt32(dateParts[0]),
                    Convert.ToInt32(dateParts[1]),
                    Convert.ToInt32(dateParts[2]));
                return testDate;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DateTime GetDateTimeString(string date, char chSplit)
        {
            try
            {
                string[] dateParts = date.Split(chSplit);

                DateTime testDate = new
                    DateTime(Convert.ToInt32(dateParts[0]),
                    Convert.ToInt32(dateParts[1]),
                    Convert.ToInt32(dateParts[2]));
                return testDate;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string ConvertDateTimeString(string date, string ReturnDateFormat, char chSplit)
        {
            try
            {
                DateTime dtTime = GetDateTimeString(date, chSplit);
                return dtTime.ToString(ReturnDateFormat);
            }
            catch (Exception ex)
            {
                return "";
            }
        }


        public static string Truncate(string value, int maxLength)
        {

            //   value = value.Replace("[ ع ]", "").Replace("[Ar]", "").Replace("[En]", "").Replace("[ ع ]", "");


            if (!string.IsNullOrEmpty(value) && value.Length > maxLength)
            {
                return String.Concat(value.Substring(0, maxLength), "...");
            }

            return value;


            //value = GeneralFunctions.Truncate(value, 20);
            //return value.Trim();
        }

        public static string GetRandomString(int length)
        {
            char[] chars = "abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
            string password = string.Empty;
            Random random = new Random();

            for (int i = 0; i < length; i++)
            {
                int x = random.Next(1, chars.Length);
                //Don't Allow Repetation of Characters
                if (!password.Contains(chars.GetValue(x).ToString()))
                    password += chars.GetValue(x);
                else
                    i--;
            }
            return password;
        }

        void resizeImage(int newHeight, int newWidth, string fromPath, string toPath)
        {
            try
            {
                FileStream stream = new FileStream(fromPath, FileMode.Open);

                try
                {
                    Bitmap originalBMP = new Bitmap(stream);


                    // Create a new bitmap which will hold the previous resized bitmap
                    Bitmap newBMP = new Bitmap(originalBMP, newWidth, newHeight);
                    // Create a graphic based on the new bitmap
                    Graphics oGraphics = Graphics.FromImage(newBMP);

                    // Set the properties for the new graphic file
                    oGraphics.SmoothingMode = SmoothingMode.AntiAlias; oGraphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    // Draw the new graphic based on the resized bitmap
                    oGraphics.DrawImage(originalBMP, 0, 0, newWidth, newHeight);
                    // Save the new graphic file to the server
                    newBMP.Save(toPath);

                    // Once finished with the bitmap objects, we deallocate them.
                    originalBMP.Dispose();
                    newBMP.Dispose();
                    oGraphics.Dispose();
                }
                catch (Exception)
                {

                }
                finally
                {
                    try
                    {
                        stream.Close();
                    }
                    catch
                    {

                    }
                }
            }
            catch
            {
            }

        }

        public bool isValidWebsite(string inputWebsite)
        {

            try
            {

                // Here we call Regex.Match.
                Match match = Regex.Match(inputWebsite, @"^((http:\/\/www\.)|(www\.)|(http:\/\/))[a-zA-Z0-9._-]+\.[a-zA-Z.]{2,5}$",
                    RegexOptions.IgnoreCase);

                // Here we check the Match instance.
                if (match.Success)
                { return true; }
                else { return false; }

            }
            catch
            {
                return false;
            }
        }


        public static bool isDateInRangeYear(string date, int StartYear /*-1 All*/, int EndYear /*-1 All*/)
        {
            try
            {
                string[] dateParts = date.Split('-');
                int year = Convert.ToInt32(dateParts[0]);

                bool result = true;
                if (StartYear != -1 && year < StartYear)
                {
                    result = false;
                }

                if (EndYear != -1 && year > EndYear)
                {
                    result = false;
                }

                return result;
            }
            catch
            {
                // if a test date cannot be created, the
                // method will return false
                return false;
            }
        }





        public void SendUserActivationEmail(string Email, string UserID, string FullName)
        {
            try
            {
                string ActivationLink = ConfigurationManager.AppSettings["ActivationLink"].ToString() + UserID;
                string body = string.Format(
                    GetFileContents("EmailTemplates\\Activation.htm"), FullName);

                var message = new EmailMessage
                {
                    Subject = "كلية محمد بن راشد للإدارة الحكومية",
                    From = "",
                    Body = body,
                    IsHtml = true
                };
                message.To.Add(new MailAddress(Email));
                new EmailServ2().SendEmail(message);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




        public static string GetFileContents(string filePath)
        {
            StreamReader objStreamReader = null;
            string fileContents = string.Empty;
            try
            {
                // Get a StreamReader class that can be used to read the file
                objStreamReader = File.OpenText(HttpContext.Current.Request.PhysicalApplicationPath + filePath);

                // Read the entire file into a string
                fileContents = objStreamReader.ReadToEnd();
            }

            finally
            {
                // Close the stream
                if (objStreamReader != null)
                {
                    objStreamReader.Close();
                }
            }

            return fileContents;
        }



    }
    public class RegexUtilities
    {
        bool invalid = false;

        public bool IsValidEmail(string strIn)
        {
            invalid = false;
            if (String.IsNullOrEmpty(strIn))
                return false;

            // Use IdnMapping class to convert Unicode domain names. 
            try
            {
                strIn = Regex.Replace(strIn, @"(@)(.+)$", this.DomainMapper,
                                      RegexOptions.None);
            }
            catch
            {
                return false;
            }

            if (invalid)
                return false;

            // Return true if strIn is in valid e-mail format. 
            try
            {
                return Regex.IsMatch(strIn,
                      @"^(?("")(""[^""]+?""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
                      @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9]{2,24}))$",
                      RegexOptions.IgnoreCase);
            }
            catch
            {
                return false;
            }
        }

        private string DomainMapper(Match match)
        {
            // IdnMapping class with default property values.
            IdnMapping idn = new IdnMapping();

            string domainName = match.Groups[2].Value;
            try
            {
                domainName = idn.GetAscii(domainName);
            }
            catch (ArgumentException)
            {
                invalid = true;
            }
            return match.Groups[1].Value + domainName;
        }
    }



    //public class EmailMessage
    //{
    //    #region Constructors

    //    public EmailMessage()
    //    {
    //        Attachments = new List<Attachment>();
    //        BCC = new List<MailAddress>();
    //        CC = new List<MailAddress>();
    //        To = new List<MailAddress>();
    //    }

    //    public EmailMessage(IList<Attachment> attachments, IList<MailAddress> bcc, string body, IList<MailAddress> cc,
    //        string from, string fromDisplayName, bool isHtml, string subject, IList<MailAddress> to)
    //    {
    //        Attachments = attachments;
    //        BCC = bcc;
    //        Body = body;
    //        CC = cc;
    //        From = from;
    //        FromDisplayName = fromDisplayName;
    //        IsHtml = isHtml;
    //        Subject = subject;
    //        To = to;
    //    }

    //    #endregion Constructors

    //    #region Properties

    //    public IList<Attachment> Attachments
    //    {
    //        get;
    //        set;
    //    }

    //    public IList<MailAddress> BCC
    //    {
    //        get;
    //        set;
    //    }

    //    public string Body
    //    {
    //        get;
    //        set;
    //    }

    //    public IList<MailAddress> CC
    //    {
    //        get;
    //        set;
    //    }

    //    public string From
    //    {
    //        get;
    //        set;
    //    }

    //    public string FromDisplayName
    //    {
    //        get;
    //        set;
    //    }

    //    public bool IsHtml
    //    {
    //        get;
    //        set;
    //    }

    //    public string Subject
    //    {
    //        get;
    //        set;
    //    }

    //    public IList<MailAddress> To
    //    {
    //        get;
    //        set;
    //    }

    //    #endregion Properties

    //}


}