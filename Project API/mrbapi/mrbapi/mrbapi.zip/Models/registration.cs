﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace mrbapi.Models
{
    public class registration
    {

         
        public string Email { get; set; }
       
        public string FirstName { get; set; }
        public string FirstNameAR { get; set; }
        public string LastName { get; set; }
        public string LastNameAR { get; set; }
        public string LoginName { get; set; }
        public string MiddleName { get; set; }
        public string MiddleNameAR { get; set; }
        public string Password { get; set; }
        public int PreferedLang { get; set; }
        public int UserId { get; set; }
      
      
      
        public string  Gender { get; set; }
       
        public string  Mobile { get; set; }
        public int NationalityRef { get; set; }


    
    }
    class registaraction

    {

        public DataTable SelectAllByEmail(string Email)
        {
            SqlConnection _sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString);
            SqlCommand Sqlcomm = new SqlCommand();
            Sqlcomm.CommandType = CommandType.StoredProcedure;
            Sqlcomm.CommandText = "SP_Users_GetByEmail";
            Sqlcomm.Connection = _sqlCon;

            SqlParameter Sqlparam;
            Sqlparam = new SqlParameter("@Email", SqlDbType.NVarChar);
            Sqlparam.Value = Email;
            Sqlcomm.Parameters.Add(Sqlparam);

            //DataSet ds = base.GetDataSet(Sqlcomm);


            SqlDataAdapter da = new SqlDataAdapter(Sqlcomm);
            DataTable dt = new DataTable("programs");
            da.Fill(dt);
           
            







         

            
            return dt;
        }





        public bool IsValidEmail(string Email)
        {
            bool isValid = true;
            try
            {
                DataTable dt = SelectAllByEmail(Email);
                if (dt.Rows.Count > 0)
                {
                    isValid = false;
                }
            }
            catch (Exception)
            {
                isValid = false;
            }
            return isValid;
        }

        public int UserRegistration_Aqdar(registration objUser)
        {
            int userID = 0;
            try
            {
                SqlConnection _sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString);
                SqlCommand Sqlcomm = new SqlCommand();
                Sqlcomm.CommandType = CommandType.StoredProcedure;
                Sqlcomm.CommandText = "SP_InsertUserProfile_mbr2";
                Sqlcomm.Connection = _sqlCon;

                Sqlcomm.Parameters.AddWithValue("@LoginName", objUser.LoginName);
                Sqlcomm.Parameters.AddWithValue("@Password", objUser.Password);
                Sqlcomm.Parameters.AddWithValue("@FirstName", objUser.FirstName);
                Sqlcomm.Parameters.AddWithValue("@LastName", objUser.LastName);
                Sqlcomm.Parameters.AddWithValue("@FirstNameAR", objUser.FirstNameAR);
                Sqlcomm.Parameters.AddWithValue("@LastNameAR", objUser.LastNameAR);
                //Sqlcomm.Parameters.AddWithValue("@PreferedLang", objUser.PreferedLang);
                Sqlcomm.Parameters.AddWithValue("@Email", objUser.Email);
                //Sqlcomm.Parameters.AddWithValue("@MiddleName", objUser.MiddleName);
                //Sqlcomm.Parameters.AddWithValue("@MiddleNameAr", objUser.MiddleNameAR);
               
                 
                Sqlcomm.Parameters.AddWithValue("@Mobile", objUser.Mobile);
                
                Sqlcomm.Parameters.AddWithValue("@NationalityRef", objUser.NationalityRef);

                bool g = true;

                if (objUser.Gender != null) { 

                    if (objUser.Gender.Trim() == "2")
                {
                    g = false;
                }
                }
                Sqlcomm.Parameters.AddWithValue("@Gender", g);
              

                var userIdParameter = Sqlcomm.CreateParameter();
                userIdParameter.ParameterName = "@UserId";
                userIdParameter.Direction = ParameterDirection.Output;
                userIdParameter.DbType = DbType.Int32;
                Sqlcomm.Parameters.Add(userIdParameter);

                _sqlCon.Open();
                int flag = Sqlcomm.ExecuteNonQuery();
                _sqlCon.Close();

                objUser.UserId = Convert.ToInt32(userIdParameter.Value);
                if (flag > 0)
                {
                    userID = objUser.UserId;
                }
            }
            catch (Exception ex)
            { throw ex; }
            return userID;
        }


    }
}