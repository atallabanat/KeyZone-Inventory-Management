﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mrbapi.Models
{
    public class T_TrainingPlan_Programs
    {

        /// <summary>
        /// Summary description for T_TrainingPlan_Programs
        /// </summary>
        #region Private Variables
        private Int64 _ID;
        private Int64 _TPRef;
        private Int64 _ProgramRef;
        private string _ValidFrom;
        private string _ValidTo;

        #endregion

        #region Public Properties
        public Int64 ID
        {
            get
            {
                return _ID;
            }
            set
            {
                _ID = value;
            }
        }
        public Int64 TrainingPlan_Ref
        {
            get
            {
                return _TPRef;
            }
            set
            {
                _TPRef = value;
            }
        }
        public Int64 ProgramRef
        {
            get
            {
                return _ProgramRef;
            }
            set
            {
                _ProgramRef = value;
            }
        }
        public string ValidFrom
        {
            get
            {
                return _ValidFrom;
            }
            set
            {
                _ValidFrom = value;
            }
        }
        public string ValidTo
        {
            get
            {
                return _ValidTo;
            }
            set
            {
                _ValidTo = value;
            }
        }

        #endregion


    }
}