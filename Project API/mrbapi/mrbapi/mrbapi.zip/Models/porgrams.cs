﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace mrbapi.Models
{
    public class Porgrams
    {
        public DataTable  GetPrograms_ByTP_ID_ForDDl( )
        {
            //SqlCommand Sqlcomm = new SqlCommand();
            //Sqlcomm.CommandType = CommandType.StoredProcedure;
            //Sqlcomm.CommandText = "Sp_GetProgramsInTrainingPlan_DDL";

            //SqlParameter Sqlparam;


            //Sqlparam = new SqlParameter("@TrainingPlan_ref", SqlDbType.BigInt);
            //Sqlparam.Value = objT_TrainingPlan_Programs.TrainingPlan_Ref;
            //Sqlcomm.Parameters.Add(Sqlparam);



            //DataSet ds = base.GetDataSet(Sqlcomm);
            //return ds;


            string cnnString = System.Configuration.ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            string TrainingPlan_ref = WebConfigurationManager.AppSettings["TrainingPlan_ref"] ;
            SqlConnection cnn = new SqlConnection(cnnString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "get_allprograms_mbr";
            //add any parameters the stored procedure might require
            cmd.Parameters.Add(
           new SqlParameter("@TrainingPlan_ref", Int64.Parse( TrainingPlan_ref)));  //17951

            cnn.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("programs");
            da.Fill(dt);

            return dt;


        }



    }
}